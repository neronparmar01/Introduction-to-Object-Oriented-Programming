#ifndef SDDS_MOVIE_H_
#define SDDS_MOVIE_H_
namespace sdds {
	struct Movie {
		char m_genres[10][11];
		};

	FILE* fptr;
	Movie movies[50];

	bool loadMovies();
	bool hasGenre(const Movie* mvp, const char genre[]);
	void displayMovie(const Movie* mvp);
	void displayMoviesWithGenre(const char genre[]);
}
#endif // !SDDS_MOVIE_H_

